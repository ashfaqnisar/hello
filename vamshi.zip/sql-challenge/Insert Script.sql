 -- ims_lookup_type --

insert into ims_lookup_type(Value,Active) values('IncedentStatus',1);
insert into ims_lookup_type(Value,Active) values('IncedentPriority',1);


-- ims_lookup_value  Status --

insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'New Incedent',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'Assigned',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'Inprogress',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'Closed',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'Declined',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentStatus'),'Waiting more Informatation',1);

-- ims_lookup_value  Priority --

insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentPriority'),'None',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentPriority'),'Minor',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentPriority'),'Major',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentPriority'),'Critical',1);
insert into  ims_lookup_value(Lookup_type_id,Value,Active) 
values ((select ID from ims_lookup_type where Value='IncedentPriority'),'Maintenance',1);

-- ims_user --

insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Alannah','Bodenwieser','Alannah Bodenwieser','*********','AlannahBodenwieser@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Bella','McWilliam','Bella McWilliam','*********','BellaMcWilliam@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Rebecca','Schardt','Rebecca Schardt','*********','RebeccaSchardt@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Benjamin','Grayson','Benjamin Grayson','*********','BenjaminGrayson@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Blake','Gouger','Blake Gouger','*********','BlakeGouger@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Elijah','Biraban','Elijah Biraban','*********','ElijahBiraban@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Joel','Cavenagh','Joel Cavenagh','*********','JoelCavenagh@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Kayla','Smeaton','Kayla Smeaton','*********','KaylaSmeaton@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Annabelle','Martens','Annabelle Martens','*********','AnnabelleMartens@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jasper','Beavis','Jasper Beavis','*********','JasperBeavis@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isla','Pottie','Isla Pottie','*********','IslaPottie@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Laura','Brunning','Laura Brunning','*********','LauraBrunning@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Amelie','Hudd','Amelie Hudd','*********','AmelieHudd@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Archie','Dinah','Archie Dinah','*********','ArchieDinah@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Alyssa','Olden','Alyssa Olden','*********','AlyssaOlden@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Finn','O Reilly','Finn OReilly','*********','FinnOReilly@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Audrey','Shipp','Audrey Shipp','*********','AudreyShipp@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Lily','Curmi','Lily Curmi','*********','LilyCurmi@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'George','Paramor','George Paramor','*********','GeorgeParamor@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Sophia','Douglass','Sophia Douglass','*********','SophiaDouglass@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Blake','Brunker','Blake Brunker','*********','BlakeBrunker@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Daniel','Lamington','Daniel Lamington','*********','DanielLamington@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Alex','Giles','Alex Giles','*********','AlexGiles@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Christopher','Hibbins','Christopher Hibbins','*********','ChristopherHibbins@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Justin','Thring','Justin Thring','*********','JustinThring@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Scarlett','Fawkner','Scarlett Fawkner','*********','ScarlettFawkner@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Alex','Henley','Alex Henley','*********','AlexHenley@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Logan','Pelsaert','Logan Pelsaert','*********','LoganPelsaert@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'David','Neumayer','David Neumayer','*********','DavidNeumayer@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Nate','Creed','Nate Creed','*********','NateCreed@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Angelina','Male','Angelina Male','*********','AngelinaMale@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jackson','Freedman','Jackson Freedman','*********','JacksonFreedman@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'William','Derrington','William Derrington','*********','WilliamDerrington@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jessica','Tolmer','Jessica Tolmer','*********','JessicaTolmer@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Dominic','Darke','Dominic Darke','*********','DominicDarke@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Edward','Charles','Edward Charles','*********','EdwardCharles@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Lucy','McClemans','Lucy McClemans','*********','LucyMcClemans@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isabelle','Farleigh','Isabelle Farleigh','*********','IsabelleFarleigh@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Scarlett','Conrad','Scarlett Conrad','*********','ScarlettConrad@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Zac','Winning','Zac Winning','*********','ZacWinning@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Emily','Imlay','Emily Imlay','*********','EmilyImlay@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Angus','Brough','Angus Brough','*********','AngusBrough@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jonathan','Hardy','Jonathan Hardy','*********','JonathanHardy@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Anna','Whitelegge','Anna Whitelegge','*********','AnnaWhitelegge@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Charlotte','Ruthven','Charlotte Ruthven','*********','CharlotteRuthven@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Makayla','Newcomb','Makayla Newcomb','*********','MakaylaNewcomb@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Sean','Joris','Sean Joris','*********','SeanJoris@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Bella','Dobbie','Bella Dobbie','*********','BellaDobbie@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Mason','Holme','Mason Holme','*********','MasonHolme@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Koby','Glennie','Koby Glennie','*********','KobyGlennie@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Spencer','Drysdale','Spencer Drysdale','*********','SpencerDrysdale@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Joel','Hake','Joel Hake','*********','JoelHake@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Laura','Moonlight','Laura Moonlight','*********','LauraMoonlight@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Declan','Royal','Declan Royal','*********','DeclanRoyal@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Joel','Astley','Joel Astley','*********','JoelAstley@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Eva','Cramsie','Eva Cramsie','*********','EvaCramsie@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Tahlia','Threlfall','Tahlia Threlfall','*********','TahliaThrelfall@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isabella','Buring','Isabella Buring','*********','IsabellaBuring@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Anthony','Fulton','Anthony Fulton','*********','AnthonyFulton@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Abby','Robinson','Abby Robinson','*********','AbbyRobinson@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Zachary','Wormald','Zachary Wormald','*********','ZacharyWormald@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Aaron','Male','Aaron Male','*********','AaronMale@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Kayla','Gerald','Kayla Gerald','*********','KaylaGerald@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Justin','Masters','Justin Masters','*********','JustinMasters@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Nate','Zimpel','Nate Zimpel','*********','NateZimpel@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'John','Saville','John Saville','*********','JohnSaville@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Connor','Petterd','Connor Petterd','*********','ConnorPetterd@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Sienna','Bruton','Sienna Bruton','*********','SiennaBruton@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Spencer','Goward','Spencer Goward','*********','SpencerGoward@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isabelle','Maria','Isabelle Maria','*********','IsabelleMaria@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isla','Logic','Isla Logic','*********','IslaLogic@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Molly','Crowley','Molly Crowley','*********','MollyCrowley@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Taylah','Kepert','Taylah Kepert','*********','TaylahKepert@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isabelle','Fry','Isabelle Fry','*********','IsabelleFry@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Ali','Carboni','Ali Carboni','*********','AliCarboni@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Charli','Radcliffe-Brown','Charli Radcliffe-Brown','*********','CharliRadcliffe-Brown@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jonathan','Pumpkin','Jonathan Pumpkin','*********','JonathanPumpkin@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Milla','Pottie','Milla Pottie','*********','MillaPottie@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Archie','Clifton','Archie Clifton','*********','ArchieClifton@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Alana','Padbury','Alana Padbury','*********','AlanaPadbury@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Grace','Oliphant','Grace Oliphant','*********','GraceOliphant@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Jaxon','Kinsella','Jaxon Kinsella','*********','JaxonKinsella@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Bianca','Steiner','Bianca Steiner','*********','BiancaSteiner@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Sophia','Elkington','Sophia Elkington','*********','SophiaElkington@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Timothy','Bonney','Timothy Bonney','*********','TimothyBonney@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Max','Boote','Max Boote','*********','MaxBoote@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Tahlia','Papathanasopoulos','Tahlia Papathanasopoulos','*********','TahliaPapathanasopoulos@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Savannah','Hartley','Savannah Hartley','*********','SavannahHartley@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Charlotte','Fitzpatrick','Charlotte Fitzpatrick','*********','CharlotteFitzpatrick@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Koby','Sharland','Koby Sharland','*********','KobySharland@rhyta.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Elizabeth','Fox','Elizabeth Fox','*********','ElizabethFox@armyspy.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Abigail','Creal','Abigail Creal','*********','AbigailCreal@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Cameron','McBride','Cameron McBride','*********','CameronMcBride@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Isla','Wight','Isla Wight','*********','IslaWight@dayrep.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Sean','Sleeman','Sean Sleeman','*********','SeanSleeman@jourrapide.com');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Daniel','Rumsey','Daniel Rumsey','*********','DanielRumsey@teleworm.us');
insert into ims_user(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,EMAIL) Values( 'Maya','Hutt','Maya Hutt','*********','MayaHutt@armyspy.com');


-- IMS_Customer



insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Mason Holme'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Koby Glennie'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Spencer Drysdale'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Joel Hake'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Laura Moonlight'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Declan Royal'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Joel Astley'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Eva Cramsie'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Tahlia Threlfall'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Isabella Buring'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Anthony Fulton'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Abby Robinson'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Zachary Wormald'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Aaron Male'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Kayla Gerald'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Justin Masters'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Nate Zimpel'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='John Saville'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Connor Petterd'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Sienna Bruton'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Spencer Goward'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Isabelle Maria'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Isla Logic'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Molly Crowley'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Taylah Kepert'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Isabelle Fry'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Ali Carboni'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Charli Radcliffe-Brown'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Jonathan Pumpkin'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Milla Pottie'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Archie Clifton'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Alana Padbury'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Grace Oliphant'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Jaxon Kinsella'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Bianca Steiner'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Sophia Elkington'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Timothy Bonney'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Max Boote'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Tahlia Papathanasopoulos'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Savannah Hartley'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Charlotte Fitzpatrick'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Koby Sharland'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Elizabeth Fox'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Abigail Creal'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Cameron McBride'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Isla Wight'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Sean Sleeman'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Daniel Rumsey'));
insert into IMS_Customer (ID) values((select Id from IMS_User where user_Name='Maya Hutt'));

-- ims_technician


insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Mason Holme'),'AL');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Connor Petterd'),'AL');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Molly Crowley'),'CA');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Ali Carboni'),'IL');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Archie Clifton'),'MD');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Sean Sleeman'),'IL');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Daniel Rumsey'),'AL');
insert into ims_technician (ID,AREA_OF_OPS) values((select Id from IMS_User where user_Name='Maya Hutt'),'AL');

-- ims_user_contact

insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Mason Holme'),'5124939223','113 Beeghley Street
Huntsville, AL 35816');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Koby Glennie'),'5125026812','3700 Spadafore Drive
Altoona, PA 16601');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Spencer Drysdale'),'5125114401','1191 Cimmaron Road
Placentia, CA 92670');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Joel Hake'),'5125201990','1017 Irving Place
O Fallon, MO 63366');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Laura Moonlight'),'5125289579','3695 Rollins Road
Broken Bow, NE 68822');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Declan Royal'),'5125377168','3968 Leverton Cove Road
Palmer, MA 01069');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Joel Astley'),'5125464757','4609 Windy Ridge Road
Angola, IN 46703');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Eva Cramsie'),'5125552346','1891 Bottom Lane
Buffalo, NY 14220');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Tahlia Threlfall'),'5125639935','1735 Scenic Way
Springfield, IL 62701');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Isabella Buring'),'5125727524','2858 Nuzum Court
Cheektowaga, NY 14227');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Anthony Fulton'),'5125815113','2380 Petunia Way
Birmingham, AL 35203');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Abby Robinson'),'5125902702','4379 Gladwell Street
Longview, TX 75601');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Zachary Wormald'),'5125990291','4842 Orchard Street
Burnsville, MN 55337');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Aaron Male'),'5126077880','2503 Arron Smith Drive
Honolulu, HI 96814');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Kayla Gerald'),'5126165469','4644 Chenoweth Drive
Crossville, TN 38555');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Justin Masters'),'5126253058','3467 Trymore Road
Valley Springs, MN 57068');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Nate Zimpel'),'5126340647','4765 Farnum Road
New York, NY 10007');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='John Saville'),'5126428236','4132 Hillside Street
Scottsdale, AZ 85259');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Connor Petterd'),'5126515825','2511 Columbia Boulevard
Baltimore, MD 21212');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Sienna Bruton'),'5126603414','762 Beechwood Drive
Hanover, MD 21076');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Spencer Goward'),'5126691003','2317 Kerry Way
Bell Gardens, CA 90201');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Isabelle Maria'),'5126778592','4988 Coal Road
Plains, PA 18705');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Isla Logic'),'5126866181','172 Felosa Drive
Abilene, TX 79602');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Molly Crowley'),'5126953770','179 Meadow Lane
Dublin, CA 94568');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Taylah Kepert'),'5127041359','1648 Kyle Street
Wilcox, NE 68982');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Isabelle Fry'),'5127128948','686 Rocky Road
Philadelphia, PA 19103');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Ali Carboni'),'5127216537','3096 Rebecca Street
Park Ridge, IL 60068');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Charli Radcliffe-Brown'),'5127304126','452 Buck Drive
South Burlington, VT 05403');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Jonathan Pumpkin'),'5127391715','1380 Bassell Avenue
Little Rock, AR 72205');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Milla Pottie'),'5127479304','3935 Karen Lane
Portland, OR 97205');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Archie Clifton'),'5127566893','4272 Doe Meadow Drive
Williamsport, MD 21795');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Alana Padbury'),'5127654482','2250 Wood Street
Houma, LA 70360');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Grace Oliphant'),'5127742071','2835 Hilltop Haven Drive
Lyndhurst, NJ 07071');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Jaxon Kinsella'),'5127829660','924 Crosswind Drive
Paducah, KY 42003');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Bianca Steiner'),'5127917249','1313 Bastin Drive
Newark, PA 19714');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Sophia Elkington'),'5128004838','1789 Fleming Way
Richmond, VA 23219');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Timothy Bonney'),'5128092427','101 Fleming Street
Enterprise, AL 36330');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Max Boote'),'5128180016','3122 Lochmere Lane
Manchester, CT 06040');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Tahlia Papathanasopoulos'),'5128267605','2647 Riverside Drive
Decatur, GA 30030');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Savannah Hartley'),'5128355194','2485 Elliot Avenue
Seattle, WA 98119');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Charlotte Fitzpatrick'),'5128442783','385 Late Avenue
Oklahoma City, OK 73102');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Koby Sharland'),'5128530372','744 White Lane
Hawkinsville, GA 31036');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Elizabeth Fox'),'5128617961','1386 Hall Street
Las Vegas, NV 89119');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Abigail Creal'),'5128705550','3438 Melrose Street
Concord, CA 94520');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Cameron McBride'),'5128793139','1314 Upland Avenue
Sylvania, OH 43560');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Isla Wight'),'5128880728','2364 Hidden Meadow Drive
Grenora, ND 58845');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Sean Sleeman'),'5128968317','3789 Garfield Road
Peoria, IL 61602');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Daniel Rumsey'),'5129055906','282 Bridge Street
Tulsa, OK 74116');
insert into ims_user_contact (user_id,Phone,Address1) values((select Id from IMS_User where user_Name='Maya Hutt'),'5129143495','4725 Ashton Lane
Austin, TX 78746');

-- ims_product --

insert into ims_product(Name) values('Laptop');
insert into ims_product(Name) values('AC');
insert into ims_product(Name) values('washing Machine');
insert into ims_product(Name) values('TV');
insert into ims_product(Name) values('Microwave Oven');
insert into ims_product(Name) values('Speakers');
insert into ims_product(Name) values('smart Phone');
insert into ims_product(Name) values('Others');


-- ims_product_model

insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 14Z990-V');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 15Z975-U.AAS7U1');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 14Z960-G');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 17Z990-V');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 14Z970-A.AAS7U1');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 15Z990-V');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 14Z950-A.AA3GU1');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'Laptop'),'LG 13Z980-U.AAW5U1');

insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG JS-Q12BPXA/NPXA 1');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG JS-Q18HUZD 1.5');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG KS-Q18ENZA 1.5');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG LWA18GWXA 1.5');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG JS-Q12AFXD 1');
insert into ims_product_model(product_id,model) values((select id from ims_product where Name = 'AC'),'LG KS-Q12ENXA 1');


-- ims_incident


insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Mason Holme'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100001',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Koby Glennie'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100002',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Spencer Drysdale'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100003',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Joel Hake'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100004',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Laura Moonlight'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100005',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Declan Royal'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100006',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Joel Astley'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100007',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Eva Cramsie'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100008',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Tahlia Threlfall'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100009',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Isabella Buring'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100010',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Anthony Fulton'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100011',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Abby Robinson'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100012',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Zachary Wormald'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100013',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Aaron Male'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100014',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Kayla Gerald'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100015',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Justin Masters'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100016',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Nate Zimpel'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100017',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='John Saville'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100018',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Connor Petterd'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100019',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Sienna Bruton'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100020',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Spencer Goward'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100021',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Isabelle Maria'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100022',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Isla Logic'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100023',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Molly Crowley'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100024',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Taylah Kepert'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Major'),'INC100025',(select ID from ims_product_model where model = 'LG JS-Q12BPXA/NPXA 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Inprogress'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Isabelle Fry'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100026',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Ali Carboni'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100027',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Charli Radcliffe-Brown'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100028',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Jonathan Pumpkin'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100029',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Milla Pottie'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100030',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Archie Clifton'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100031',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Alana Padbury'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100032',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Grace Oliphant'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100033',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Jaxon Kinsella'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100034',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Bianca Steiner'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100035',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Sophia Elkington'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100036',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Timothy Bonney'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100037',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Max Boote'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100038',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Tahlia Papathanasopoulos'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100039',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Savannah Hartley'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100040',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Charlotte Fitzpatrick'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100041',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Koby Sharland'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100042',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Elizabeth Fox'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'None'),'INC100043',(select ID from ims_product_model where model = 'LG 14Z990-V'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Closed'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Abigail Creal'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Maintenance')
,'INC100044',(select ID from ims_product_model where model = 'LG JS-Q12AFXD 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Waiting more Informatation'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Cameron McBride'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Maintenance')
,'INC100045',(select ID from ims_product_model where model = 'LG JS-Q12AFXD 1'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Waiting more Informatation'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Isla Wight'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100046',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Sean Sleeman'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Critical'),'INC100047',(select ID from ims_product_model where model = 'LG LWA18GWXA 1.5'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Declined'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Daniel Rumsey'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100048',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);
insert into ims_incident(CUSTOMER_ID,PRIORITY_ID,INCIDENT_NUMBER,PRODUCT_MODEL_ID,DESCRIPTION,CURRENT_STATUS_ID,BEST_TIME_TO_REACH,CREATED_ON) values( 
(select id from IMS_User where user_name ='Maya Hutt'),(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentPriority' and LTV.Value = 'Minor'),'INC100049',(select ID from ims_product_model where model = 'LG 14Z960-G'),'Device is not working properly',(select  LTV.ID from IMS_lookup_Value LTV,IMS_lookup_Type LT where  LT.ID = LTV.Lookup_type_id and LT.Value = 'IncedentStatus' and LTV.Value = 'Assigned'),'Any Time',CURRENT_DATE);



-- ims_incident_status

insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100001'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100001'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100002'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100002'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100003'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100003'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100004'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100004'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100005'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100005'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100006'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100006'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100007'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100007'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100008'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100008'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100009'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100009'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100010'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100010'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100011'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100011'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100012'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100012'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100013'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100013'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100014'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100014'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100015'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100015'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100016'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100016'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100017'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100017'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100018'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100018'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100019'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100019'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100020'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100020'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100021'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100021'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100022'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100022'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100023'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100023'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100024'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100024'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100025'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100025'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100026'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100026'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100027'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100027'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100028'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100028'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100029'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100029'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100030'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100030'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100031'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100031'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100032'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100032'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100033'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100033'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100034'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100034'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100035'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100035'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100036'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100036'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100037'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100037'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100038'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100038'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100039'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100039'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100040'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100040'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100041'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Sean Sleeman'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100041'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100042'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Daniel Rumsey'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100042'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100043'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Connor Petterd'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100043'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100044'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Maya Hutt'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100044'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100045'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Mason Holme'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100045'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100046'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Molly Crowley'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100046'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100047'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Archie Clifton'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100047'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100048'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100048'),CURRENT_DATE);
insert into ims_incident_status (INCIDENT_ID,TECHNICIAN_ID,STATUS_ID,START_TIME) values((select Id from ims_incident where INCIDENT_NUMBER = 'INC100049'),(select IT.ID from ims_technician IT ,IMS_USER IU where IU.ID= IT.ID and IU.User_name = 'Ali Carboni'),(select CURRENT_STATUS_ID from ims_incident where INCIDENT_NUMBER = 'INC100049'),CURRENT_DATE);

