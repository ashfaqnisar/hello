package BannkingSystem;

public class AccountStatus extends AccountDetails {
    private int accountNo;
    boolean currentStatus;

    @Override
    public int getAccountNo() {
        return accountNo;
    }

    @Override
    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public boolean isCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(boolean currentStatus) {
        this.currentStatus = currentStatus;
    }
}
