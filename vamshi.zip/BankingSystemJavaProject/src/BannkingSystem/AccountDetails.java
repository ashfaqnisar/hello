package BannkingSystem;

public class AccountDetails extends verifyLogin1 {
    private int accountNo;
    private String username;
    private int amount;
    private String bankName;
    private String bnakBranch;
    private String IFSCCode;

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBnakBranch() {
        return bnakBranch;
    }

    public void setBnakBranch(String bnakBranch) {
        this.bnakBranch = bnakBranch;
    }

    public String getIFSCCode() {
        return IFSCCode;
    }

    public void setIFSCCode(String IFSCCode) {
        this.IFSCCode = IFSCCode;
    }
}
