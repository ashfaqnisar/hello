package BannkingSystem;

public class MiniStatement extends verifyLogin1 {
    public void printMiniStatment()
    {
        //print the last 5 transcations from database
    }
}
