package BannkingSystem;


public class RegisterUser implements User {
static int status=0;


	@Override
	public int register(String username, String password, double amount, String adderess, double phone) {
		return 0;
	}

	@Override
	public String withdraw(int acno, String uname, String pwd, int amt) {
		return null;
	}

	@Override
	public String deposit(int acno, String uname, String pwd, int amt) {
		return null;
	}




	@Override
	public String balance(int acno, String uname, String pass) {
		return null;
	}

	//int accountno=1;
public static void register(String accountNo, String username,String dob){

}
	//public static int register(String email,String password,String gender,String country,String name){


		


}
