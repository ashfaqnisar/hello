package BannkingSystem;

public class verifyLogin1 implements User {


	@Override
	public int register(String username, String password, double amount, String adderess, double phone) {
		return 0;
	}

	@Override
	public String withdraw(int acno, String uname, String pwd, int amt) {
		return null;
	}

	@Override
	public String deposit(int acno, String uname, String pwd, int amt) {
		return null;
	}





	@Override
	public String balance(int acno, String uname, String pass) {
		return null;
	}

	public static boolean checkLogin(int accountno, String username, String password){
	boolean status=false;
	//if user login credentials match status=true
	return status;
}
}
