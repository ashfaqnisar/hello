package BannkingSystem;

public interface User 
{
    public int register(String username,String password,double amount,String adderess,
                        double phone) ;
    public String withdraw(int acno,String uname,String pwd,int amt) ;
    public String deposit(int acno,String uname,String pwd,int amt) ;
    public String balance(int acno,String uname,String pass) ;
}