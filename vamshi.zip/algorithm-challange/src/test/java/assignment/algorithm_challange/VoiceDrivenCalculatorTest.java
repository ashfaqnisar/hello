package assignment.algorithm_challange;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class VoiceDrivenCalculatorTest {
	// #VDC
	@Test
	public void testSimpleCalculator() {
		VoiceDrivenCalculator calculator = new VoiceDrivenCalculator();
		assertTrue(calculator.calculate("9+8") == 17);
		assertTrue(calculator.calculate("9-8") == 1);
		assertTrue(calculator.calculate("10-8") == 2);
		assertTrue(calculator.calculate("100-90") == 10);
	}
}
