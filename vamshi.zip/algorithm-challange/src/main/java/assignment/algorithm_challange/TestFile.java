package assignment.algorithm_challange;

public class TestFile {
    public static void main(String[] args) {
        VoiceDrivenCalculator obj=new VoiceDrivenCalculator();
        int res=obj.calculate("8+9");
        System.out.println(res);
    }
}
