package assignment.algorithm_challange;
public class VoiceDrivenCalculator implements FuncInter1 {

	public int calculate(String expression) {
		String[] operands = {"","",""};
		String[] comp = expression.split("");
		int j=0;
		for(int i=0;i<comp.length;i++){
			if(comp[i].matches("[0-9]+")) {


					operands[j]=operands[j].concat(comp[i]);


			}
			else
			{
				operands[2]=comp[i];
				j++;
			}
		}


		System.out.println(operation(Integer.parseInt(operands[0]),Integer.parseInt(operands[1]),
				operands[2].charAt(0)));
		return (operation(Integer.parseInt(operands[0]),Integer.parseInt(operands[1]),
				operands[2].charAt(0)));
	}

	@Override
	public int operation(int a, int b,char op) {
		switch (op)
		{
			case '+':
				return a+b;
			case '-': return a-b;
			case '*': return a*b;
			case '/': return a/b;
			case '%': return a%b;
			default:
				throw new IllegalStateException("Unexpected value: " + op);
		}
	}




}

interface FuncInter1 {
	int operation(int a, int b,char op);
}
